#include<bits/stdc++.h>
using namespace  std;

int main() {
    int t,n, c0,c1,h;
    
    cin>>t;
    
    while(t--)
    {
        cin>>n>>c0>>c1>>h;
        vector<char>v[n];
        
        for(int i=0;i<n;i++)
        {
            char a;
            cin>>a;
            v.push_back(a);
        }
        
        
    }
    return 0;
}