#include<bits/stdc++.h>

using namespace std;

mt19937 rng(time(0));


void MergeArr(vector<int>&nums,int L,int R)
{
    vector<int>temp(R-L+1);
    int M=L+(R-L)/2;
    int i=0,iL=L,iR=M+1;
    while(iL<=M && iR<=R)
    {
        if(nums[iL]<=nums[iR])
        {
            temp[i++]=nums[iL++];
        }
        else
        {
            temp[i++]=nums[iR++];
        }

    }
    while(iL<=M) temp[i++]=nums[iL++];
    while(iR<=R) temp[i++]=nums[iR++];
    for(int i=L; i<=R; i++)
    {
        nums[i]=temp[i-L];
    }

}

void MergeSort(vector<int>&nums,int L,int R)
{
    if (L>=R) return;
    int M=L+(R-L)/2;
    MergeSort(nums,L,M);
    MergeSort(nums,M+1,R);
    MergeArr(nums,L,R);

}

void MergeSort(vector<int>&nums)
{
    MergeSort(nums,0,nums.size()-1);
}

int main()
{
    vector<int> arr;

    int N=1e7;
    for(int i=0; i<N; i++)
    {
        arr.push_back(rng()%100000);
    }

    MergeSort(arr);

    if(is_sorted(arr.begin(),arr.end()))
    {
        cout<<"Successgully!!\n";
    }
    else
    {
        cout<<"Not Successfully!!\n";
    }
    return 0;
}
