#include<bits/stdc++.h>
using namespace std;

const int MAX_N=1e5+6;
vector<int>arr;
int tree[4*MAX_N+5];

void BuildTree(int st,int en,int nd)
{
    if(st>en) return;
    else if(st==en)
    {
        tree[nd]=arr[st];
        return;
    }
    else
    {
        int M=st+(en-st)/2;
        BuildTree(st,M,nd+nd);
        BuildTree(M+1,en,nd+nd+1);
        tree[nd]=tree[nd+nd] + tree[nd+nd+1];
    }
}

int Query(int st,int en,int nd,int l,int r)
{

    if( (en<l) || (r<st))
    {
        cout<<st<<" "<<en<<" is out of range\n";
        return 0;
    }
    if(l<=st && en<=r)
    {
        cout<<st<<" "<<en<<" is within range\n ";
        return tree[nd];
    }
    // cout<<"test\n";
    int M=st+(en-st)/2;
    int leftQuery=Query(st,M,nd+nd,l,r);
    int rightQuery=Query(M+1,en,nd+nd+1,l,r);
    return leftQuery+rightQuery;

}

int main()
{
    freopen("test.txt","r",stdin);
    int N;
    scanf("%d",&N);
    arr.resize(N+6);
    for(int i=0; i<N; i++) scanf("%d",&arr[i]);

    BuildTree(0,N-1,1);

//    for(int  i=1;i<=15;i++)
//    {
//        cout<<"tree partial root Sum "<<i<<" : "<<tree[i]<<"\n";
//    }
    cout<<Query(0,N-1,1,2,6);


    return 0;
}
