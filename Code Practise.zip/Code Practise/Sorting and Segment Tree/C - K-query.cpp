#include<bits/stdc++.h>
using namespace std;

const int MAXN=5e5+10;

vector<long int> tree[4*MAXN];
long int arr[MAXN];

void MergeTree(int st,int en,int nd)
{
    auto &left=tree[nd+nd];
    auto &right=tree[nd+nd+1];
    int iL=0,iR=0;
    while(iL<left.size() && iR<right.size())
    {
        if(left[iL]<=right[iR])
        {
            tree[nd].push_back(left[iL++]);
        }
        else tree[nd].push_back(right[iR++]);
    }
    while(iL<left.size()) tree[nd].push_back(left[iL++]);
    while(iR<right.size()) tree[nd].push_back(right[iR++]);
}

void BuildTree(int st,int en,int nd)
{
    if(st>en) return;
    else if(st==en)
    {
        tree[nd].push_back(arr[st]);
    }
    else
    {
        int m=st+(en-st)/2;
        BuildTree(st,m,nd+nd);
        BuildTree(m+1,en,nd+nd+1);
        MergeTree(st,en,nd);
    }
}


int Query(int st,int en,int nd,int l,int r,int val)
{
    if(st>r || l>en) return 0;
    else if(st>=l && en<=r)
    {
        int k=upper_bound(tree[nd].begin(),tree[nd].end(),val)-tree[nd].begin();
        return k;
    }
    else
    {
        int m=st+(en-st)/2;
        int left=Query(st,m,nd+nd,l,r,val);
        int right=Query(m+1,en,nd+nd+1,l,r,val);
        return left+right;
    }
}
int main()
{
    int N,Q;
    scanf("%d%",&N,&Q);
    vector<long int> nums;
    for(int i=1; i<=N; i++)
    {
        scanf("%ld",&arr[i]);
        nums.push_back(arr[i]);
    }

    sort(nums.begin(),nums.end());
    for(int i=1; i<=N; i++)
    {
        arr[i]=lower_bound(nums.begin(),nums.end(),arr[i])-nums.begin()+1;
    }
    BuildTree(1,N,1);
    //scanf("%d",&Q);
    for(int i=1; i<=Q; i++)
    {
        int l,r,k,low,high,mid,res;
        scanf("%d%d%d",&l,&r,&k);
        low=1,high=N;
        while(low<=high)
        {
            mid=low+(high-low)/2;
            int temp=Query(1,N,1,l,r,mid);
            if(temp>=k)
            {
                res=mid;
                high=mid-1;
            }
            else low=mid+1;
        }
        cout<<nums[res-1]<<"\n";

    }
    return 0;
}
