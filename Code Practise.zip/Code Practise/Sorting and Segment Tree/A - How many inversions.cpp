#include<bits/stdc++.h>
using namespace std;
long long int Inv_value;

void MergeArr(vector<int>&nums,int L,int R)
{
    int M=L+(R-L)/2;
    int i=L,j=M+1;
    vector<int> temp;
    while(i<=M && j<=R)
    {
        if(nums[i]<=nums[j]) temp.push_back(nums[i++]);
        else{
            Inv_value+=((M+1)-i);
            temp.push_back(nums[j++]);
        }
    }
    while(i<=M){
            temp.push_back(nums[i++]);
    }
    while(j<=R){
            temp.push_back(nums[j++]);
    }

    for(int i=L;i<=R;i++){
            nums[i]=temp[i-L];
    }

}

void MergeSort(vector<int>&nums,int L,int R)
{
    if(L>=R) return;
    int M=L+(R-L)/2;
    MergeSort(nums,L,M);
    MergeSort(nums,M+1,R);
    MergeArr(nums,L,R);
}
int main()
{

    int a,N;


    while(cin>>N)
    {
        if(N==0) {

            break;
        }
        vector<int>nums;
        for(int i=0;i<N;i++)
        {

            cin>>a;
            //cout<<"\n";
            nums.push_back(a);

        }

        MergeSort(nums,0,N-1);
        cout<<Inv_value<<"\n";

        Inv_value=0;
    }

    return 0;
}
