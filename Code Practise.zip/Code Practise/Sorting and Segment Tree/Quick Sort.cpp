#include<bits/stdc++.h>
using namespace std;

mt19937 rng(time(0));

int MakePartition(vector<int>&nums,int L,int R)
{
    int pvt=nums[R];
    int i=L-1;
    for(int j=L;j<R;j++)
    {
        if(nums[j]<=pvt){
           swap(nums[j],nums[i+1]);
           i++;

        }
    }
    swap(nums[i+1],nums[R]);
    return i+1;
}
void QuickSort(vector<int>&nums,int L,int R)
{
    if(L>=R) return;
    int p=MakePartition(nums,L,R);
    while(p>0 && nums[p]==nums[p-1]) p--;
    QuickSort(nums,L,p-1);
    while(p<R && nums[p]==nums[p+1]) p++;
    QuickSort(nums,p+1,R);
}

void QuickSort(vector<int>&nums)
{
    shuffle(nums.begin(),nums.end(),rng);
    QuickSort(nums,0,nums.size()-1);
}
int main()
{
    int N=1e7+6;

    vector<int> arr;

    for(int i=0;i<N;i++)
    {
        arr.push_back(i);
    }
    QuickSort(arr);
    if(is_sorted(arr.begin(),arr.end())){
        cout<<"Sorting Successfully!!\n";
    }
    else{
        cout<<"Not SuccessFully!!\n";
    }

    return 0;
}
