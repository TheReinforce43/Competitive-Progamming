#include<bits/stdc++.h>
using namespace std;
const int MAXN=1e5+10;

int arr[MAXN];
vector<int> tree[4*MAXN];

void MergeSortVector(vector<int>&nums,int L,int R)
{
    vector<int>temp;

    int M=L+(R-L)/2;
    int iL=L,iR=M+1;

    while(iL<=M && iR<=R)
    {
        if(nums[iL]<=nums[iR]) temp.push_back(nums[iL++]);
        else temp.push_back(nums[iR++]);
    }
    while(iL<=M) temp.push_back(nums[iL++]);
    while(iR<=R) temp.push_back(nums[iR++]);

    for(int i=L; i<=R; i++)
    {
        nums[i]=temp[i-L];
    }
}

void MergeSort(vector<int>&nums,int L,int R)
{
    if(L>=R) return ;
    int M=L+(R-L)/2;
    MergeSort(nums,L,M);
    MergeSort(nums,M+1,R);
    MergeSortVector(nums,L,R);
}
void MergeTree(int L,int R,int nd)
{
    auto &left=tree[nd+nd];
    auto &right=tree[nd+nd+1];
    int iL=0,iR=0;
    while(iL<left.size() && iR<right.size())
    {
        if(left[iL]<=right[iR]) tree[nd].push_back(left[iL++]);
        else tree[nd].push_back(right[iR++]);
    }

    while(iL<left.size()) tree[nd].push_back(left[iL++]);
    while(iR<right.size()) tree[nd].push_back(right[iR++]);
}

void BuildTree(int L,int R,int nd)
{
    if(L>R) return;
    if(L==R)
    {
        tree[nd].push_back(arr[L]);
        return;
    }
    int M=L+(R-L)/2;
    BuildTree(L,M,nd+nd);
    BuildTree(M+1,R,nd+nd+1);
    MergeTree(L,R,nd);
}

void Print(vector<int>arr)
{
    for(auto u:arr) cout<<u<<" ";
}

int Query(int st,int en,int nd,int l,int r,int val)
{
    if(en<l || r<st) return 0;
    if(l<=st && en<=r)
    {
        int k=upper_bound(tree[nd].begin(),tree[nd].end(),val)- tree[nd].begin();
        return k;
    }
    int m=(st+en)/2;
    int left=Query(st,m,nd+nd,l,r,val);
    int right=Query(m+1,en,nd+nd+1,l,r,val);
    return left+right;
}

int main()
{
    vector<int>nums;
    int N,Q;
    scanf("%d%d",&N,&Q);

    for(int i=1; i<=N; i++)
    {
        scanf("%d",&arr[i]);
        nums.push_back(arr[i]);
    }

    MergeSort(nums,0,N-1);

    for(int i=1; i<=N; i++)
    {
        arr[i]=lower_bound(nums.begin(),nums.end(),arr[i])- nums.begin()+1;
    }

    BuildTree(1,N,1);


    for(int i=0; i<Q; i++)
    {
        int l,r,k,low,mid,high,res;
        scanf("%d%d%d",&l,&r,&k);
        low=1,high=N;
        while(low<=high)
        {
            mid=low+(high-low)/2;
            int temp=Query(1,N,1,l,r,mid);

            if(temp>=k)
            {
                cout<<temp<<""<<low<<" "<<high<<"\n" ;
                res=mid;
                high=mid-1;
            }
            else low=mid+1;
        }
        cout<<nums[res-1]<<"\n";;
    }

    return 0;
}
