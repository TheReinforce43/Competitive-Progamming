#include<bits/stdc++.h>
using namespace std;

const int max_N=1e3+5;
vector<int> tree[4*max_N+5];

void MergeTree(int nd)
{
    auto &left=tree[nd+nd];
    auto &right=tree[nd+nd+1];
    int  iL=0,iR=0;

    while(iL<left.size() && iR<right.size())
    {

        if(left[iL]<=right[iR]) tree[nd].push_back(left[iL++]);
        else tree[nd].push_back(right[iR++]);
    }
    while(iL<left.size()) tree[nd].push_back(left[iL++]);
    while(iR<right.size()) tree[nd].push_back(right[iR++]);
}

void BuildTree(vector<int>&nums,int L,int R,int nd)
{
    if(L>R ) return ;
    else if(L==R)
    {
        tree[nd].push_back(nums[L]);
        return;
    }
    else
    {
        int M=L+(R-L)/2;
        BuildTree(nums,L,M,nd+nd);
        BuildTree(nums,M+1,R,nd+nd+1);
        MergeTree(nd);
    }
}

void PrintArr(vector<int>&nums)
{
    for(auto &ele:nums)
    {
        cout<<ele<<" ";
    }
    cout<<"\n";
}
int main()
{

    vector<int>nums= {10,9,-1,4,-3,-2,-5,25,14,3,9,12,24,18,-5,0};

    BuildTree(nums,0,nums.size()-1,1);

    for(int i=1; i<=31; i++)
    {
        cout<<"arr "<<i<<" : ";
        PrintArr(tree[i]);
    }


    return 0;
}
